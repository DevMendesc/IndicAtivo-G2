package br.com.empiricus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//BY THIAGOSILVA
@SpringBootApplication
public class ProjetoRestFulApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoRestFulApplication.class, args);
	}

}
