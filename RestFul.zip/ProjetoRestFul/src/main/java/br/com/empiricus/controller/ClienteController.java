package br.com.empiricus.controller;

//BY THIAGOSILVA
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.empiricus.model.Cliente;
import br.com.empiricus.service.ClienteService;

@RestController
@RequestMapping("/api/clientes")
public class ClienteController {
	
	private ClienteService clienteService;

	public ClienteController(ClienteService clienteService) {
		super();
		this.clienteService = clienteService;
	}
	
	
	//Criação da API REST Cliente
	//http://localhost:8080/api/clientes
	@PostMapping()
	public ResponseEntity<Cliente> saveCliente(@RequestBody Cliente cliente){
		return new ResponseEntity<Cliente>(clienteService.saveCliente(cliente), HttpStatus.CREATED);
		
	}
	
	//Criação de Busca  API REST Cliente
	//http://localhost:8080/api/clientes/
	@GetMapping
	public List<Cliente> getAllClientes(){
		return clienteService.getAllClientes();
	}
	
	//Criação de Busca por id API REST Cliente
	//http://localhost:8080/api/clientes/1
	@GetMapping("{id}")
	public ResponseEntity<Cliente> getClienteById(@PathVariable("id") long clienteid){
		return new ResponseEntity<Cliente>(clienteService.getClienteById(clienteid), HttpStatus.OK);
	}
	
	//CRIAÇÃO DE ATUALIZAÇÃO API REST Cliente
	//http://localhost:8080/api/clientes/1
	@PutMapping("{id}")
	public ResponseEntity<Cliente> updateCliente(@PathVariable("id") long id
												,@RequestBody Cliente cliente){
		return new ResponseEntity<Cliente>(clienteService.updateCliente(cliente, id), HttpStatus.OK);
	}
	
	//CRIAÇÃO DO DELETE API REST Cliente
	//http://localhost:8080/api/clientes/1
	@DeleteMapping("{id}")
	public ResponseEntity<String> deleteCliente(@PathVariable("id") long id){
		
		//DELETANDO DO BD
		clienteService.deleteCliente(id);
		return new ResponseEntity<String>("Cliente Deletado com sucesso!.", HttpStatus.OK);
	}
	
	
	
}
