package br.com.empiricus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoRestFulApplicationTests {

	@Test
	void contextLoads() {
	}

}
